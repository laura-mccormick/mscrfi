package objects;

public class ConversationDTO {


    public ConversationDTO() {

    }

    public ConversationDTO(String alertId, String conversationId, String subject, String[] contacts, boolean open, String dateOpened, String dateClosed) {
        this.alertId = alertId;
        this.conversationId = conversationId;
        this.subject = subject;
        this.contacts=contacts;
        this.open = open;
        this.dateOpened = dateOpened;
        this.dateClosed = dateClosed;
    }

    private String alertId;
    private String conversationId;
    private String subject;
    private String[] contacts;
    private boolean open;
    private String dateOpened;
    private String dateClosed;

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    public String getAlertId() {
        return alertId;
    }

    public void setAlertId(String alertId) {
        this.alertId = alertId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String[] getContacts() {
        return contacts;
    }

    public void setContacts(String[] contacts) {
        this.contacts = contacts;
    }

    public String getDateOpened() {
        return dateOpened;
    }

    public void setDateOpened(String dateOpened) {
        this.dateOpened = dateOpened;
    }

    public String getDateClosed() {
        return dateClosed;
    }

    public void setDateClosed(String dateClosed) {
        this.dateClosed = dateClosed;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }
}
