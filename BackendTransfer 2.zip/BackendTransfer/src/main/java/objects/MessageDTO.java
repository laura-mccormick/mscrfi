package objects;

import java.util.List;

import springfox.documentation.spring.web.json.Json;

public class MessageDTO {


	private String conversationId;
    private String messageId;
    private String subject;
    private String sender;
    private List<String> recipientsTo;
    private List<String> recipientsCC;
    private List<String> recipientsBCC;
    private String body;
    private String timestamp;


	public MessageDTO() {

    }

    public MessageDTO(String messageId, String conversationId, String subject, String sender, List<String> recipientsTo, List<String> recipientsCC, List<String> recipientsBCC, String body, String timestamp) {
        this.messageId = messageId;
        this.conversationId = conversationId;
        this.subject = subject;
        this.sender = sender;
        this.recipientsTo = recipientsTo;
        this.recipientsCC = recipientsCC;
        this.setRecipientsBCC(recipientsBCC);
        this.body = body;
        this.timestamp = timestamp;
    }


    public MessageDTO(String messageId, String conversationId, String subject, String sender, String body, String timestamp) {
		this.messageId = messageId;
		this.conversationId = conversationId;
		this.subject = subject;
		this.sender = sender;
		this.body = body;
		this.timestamp = timestamp;
	}


    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public List<String> getRecipientsTo() {
        return recipientsTo;
    }

    public void setRecipientsTo(List<String> recipientsTo) {
        this.recipientsTo = recipientsTo;
    }

    public List<String> getRecipientsCC() {
        return recipientsCC;
    }

    public void setRecipientsCC(List<String> recipientsCC) {
        this.recipientsCC = recipientsCC;
    }
    
    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

	public List<String> getRecipientsBCC() {
		return recipientsBCC;
	}

	public void setRecipientsBCC(List<String> recipientsBCC) {
		this.recipientsBCC = recipientsBCC;
	}
}
