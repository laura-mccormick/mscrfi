package CodeCreator;

public interface ICodeCreator {

    String generateRandom();
}
