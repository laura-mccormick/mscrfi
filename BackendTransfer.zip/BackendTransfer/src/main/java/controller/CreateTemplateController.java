package controller;

import objects.TemplateDAO;
import objects.TemplateDTO;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;

@EnableAutoConfiguration
@Controller
@RequestMapping(value = "/createTemplate")

public class CreateTemplateController extends HttpServlet {

    private static TemplateDAO dao = new TemplateDAO();


    @RequestMapping("/save")
    @ResponseBody
    public void saveTemplateDummy(HttpServletRequest request, HttpServletResponse response) {
        String title = request.getParameter("title");
        String body = request.getParameter("body");
        String uniqueID = UUID.randomUUID().toString();
        new TemplateDTO(uniqueID, title, body, "author@email.com"); // Need to pass the author as a parameter like title and body when its accessible

    }

}


