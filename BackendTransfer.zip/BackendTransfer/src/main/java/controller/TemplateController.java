package controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import objects.TemplateDAO;
import objects.TemplateDTO;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;


@EnableAutoConfiguration
@Controller
@RequestMapping(value = "/storedTemplates")

public class TemplateController extends HttpServlet {

    private static TemplateDAO dao = new TemplateDAO();

    @RequestMapping("saved/")
    protected void httpServletGrabber(HttpServletRequest request,
                                      HttpServletResponse response) throws ServletException, IOException, MessagingException, SQLException {

        response.setContentType("text/html");

        String title, templateBody;

        title = request.getParameter("templateTitle");
        templateBody = request.getParameter(("templateBody"));

    }


    @RequestMapping("/templateListFullDB")
    @ResponseBody
    public List<TemplateDTO> returnTemplateListFullDB() throws SQLException {

        return dao.returnTemplateListFullDB();

    }


    @RequestMapping("/templateListFullDummy")
    @ResponseBody
    public List<TemplateDTO> returnTemplateListFullDummy() throws SQLException, JsonProcessingException {

        return dao.returnTemplateListFullDummy();

    }

    @RequestMapping("/template/{templateId}")
    @ResponseBody
    public TemplateDTO returnTemplateByIdDummy(@PathVariable("templateId") String templateId) throws SQLException, JsonProcessingException {

        return dao.returnTemplateByIdDummy(templateId);

    }

}


