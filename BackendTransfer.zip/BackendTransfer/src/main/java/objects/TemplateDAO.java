package objects;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.security.InvalidParameterException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Component
@EnableAutoConfiguration
public class TemplateDAO {

    public TemplateDAO(){
        populateDummyList();
    }

    private static JdbcTemplate jdbc = new JdbcTemplate();

    public TemplateDTO createTemplateObject(String templateId, String title, String templateBody, String templateAuthor) throws SQLException, IOException {

        TemplateDTO template = new TemplateDTO();

        template.setTemplateId(TemplateIdSetter(template));
        template.setTemplateTitle(title);
        template.setTemplateBody(templateBody);
        template.setTemplateAuthor((System.getProperty("user.name") + "imceu.eu.ssmb.com"));


        pushTemplateObjectToDB(template);

        return template;
    }

    //method to set template ID
    public static String TemplateIdSetter(TemplateDTO template) throws SQLException {

        List<TemplateDTO> templateList = new ArrayList<>();

        if (templateList.isEmpty()) {
            template.setTemplateId("TEMP" + 1);


        } else if (templateList.size() > 0) {

            template.setTemplateId("TEMP" + (templateList.size() + 1));


        }

        return template.getTemplateId();
    }

    //method to push template object to DB
    public void pushTemplateObjectToDB(TemplateDTO template) throws SQLException {

        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Dissertation", "TOANDEAF",
                "Waffle12");
        Statement st = connection.createStatement();
        String sql = String.format("INSERT INTO demo.template (tempId, tempTitle, tempField, tempAuthor) VALUES('%s', '%s', '%s', '%s');", template.getTemplateId(), template.getTemplateTitle(), template.getTemplateBody(), template.getTemplateAuthor());
        st.executeLargeUpdate(sql);
    }


    public List<TemplateDTO> returnTemplateListFullDB() throws SQLException {

        List<TemplateDTO> templateList = new ArrayList<>();

        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Dissertation", "TOANDEAF",
                "Waffle12");
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM demo.template");

        while (rs.next()) {

            templateList.add(new TemplateDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));

        }

        connection.close();
        return templateList;

    }

    //manually populates templateList
    public List<TemplateDTO> returnTemplateListFullDummy() throws JsonProcessingException {
        return templateListDummy;
    }

    //method to add/create new template based on user input

    //?????


    //method to remove template
    public static void removeTemplate() {


    }


    public TemplateDTO returnTemplateByIdDummy(String id) throws JsonProcessingException {
        List<TemplateDTO> templateDTOList = returnTemplateListFullDummy();

        for(TemplateDTO template : templateDTOList ){
            if(template.getTemplateId().equalsIgnoreCase(id)){
                return template;
            }
        }
        throw new InvalidParameterException("An invalid template ID was requested: " + id);
    }

    private void populateDummyList()
    {
        TemplateDTO temp1 = new TemplateDTO("TEMP1", "EMEA BASIC", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin bibendum molestie augue, eu elementum ipsum commodo ut. Nullam tristique posuere pharetra. Integer blandit dolor non massa dignissim "
                + "tincidunt. Cras convallis ante ornare dolor vestibulum, vel viverra tortor vulputate. Nam vehicula ornare pellentesque. Vestibulum venenatis sagittis felis nec mollis. Integer dictum varius sem placerat"
                + " fermentum. Pellentesque imperdiet massa in lacinia vehicula. Donec at aliquam neque. Ut congue, mi vitae sagittis pulvinar, velit augue cursus urna, nec posuere purus ante id augue. Donec sapien lectus,"
                + " euismod sed massa at, imperdiet feugiat nunc. Proin dapibus dictum nisi sed finibus. Morbi pellentesque cursus ullamcorper. Praesent ullamcorper non massa id tincidunt. Etiam auctor, sapien nec tristique"
                + " porta, nisl nunc rhoncus nibh, maximus hendrerit quam dui sed libero. Aliquam egestas vulputate sapien tincidunt tristique. Aliquam nec nunc ut turpis efficitur gravida ut quis sem. Maecenas ac sapien "
                + "sed dolor porta maximus ut id leo. Suspendisse potenti. Sed a diam aliquet, interdum risus id, fermentum lectus. Nullam elit lorem, malesuada a elementum nec, laoreet eget nunc. Aliquam pharetra purus id "
                + "urna pretium, at congue sapien hendrerit. Morbi rhoncus consectetur aliquam. Vivamus vel mauris dictum, tincidunt urna cursus, euismod magna. Vestibulum pulvinar hendrerit augue, ut rutrum erat rhoncus in."
                + " Donec aliquet enim lacus, a dapibus tortor volutpat luctus. Nulla massa quam, accumsan quis ligula ut, auctor tincidunt justo."+
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin bibendum molestie augue, eu elementum ipsum commodo ut. Nullam tristique posuere pharetra. Integer blandit dolor non massa dignissim "
                + "tincidunt. Cras convallis ante ornare dolor vestibulum, vel viverra tortor vulputate. Nam vehicula ornare pellentesque. Vestibulum venenatis sagittis felis nec mollis. Integer dictum varius sem placerat"
                + " fermentum. Pellentesque imperdiet massa in lacinia vehicula. Donec at aliquam neque. Ut congue, mi vitae sagittis pulvinar, velit augue cursus urna, nec posuere purus ante id augue. Donec sapien lectus,"
                + " euismod sed massa at, imperdiet feugiat nunc. Proin dapibus dictum nisi sed finibus. Morbi pellentesque cursus ullamcorper. Praesent ullamcorper non massa id tincidunt. Etiam auctor, sapien nec tristique"
                + " porta, nisl nunc rhoncus nibh, maximus hendrerit quam dui sed libero. Aliquam egestas vulputate sapien tincidunt tristique. Aliquam nec nunc ut turpis efficitur gravida ut quis sem. Maecenas ac sapien "
                + "sed dolor porta maximus ut id leo. Suspendisse potenti. Sed a diam aliquet, interdum risus id, fermentum lectus. Nullam elit lorem, malesuada a elementum nec, laoreet eget nunc. Aliquam pharetra purus id "
                + "urna pretium, at congue sapien hendrerit. Morbi rhoncus consectetur aliquam. Vivamus vel mauris dictum, tincidunt urna cursus, euismod magna. Vestibulum pulvinar hendrerit augue, ut rutrum erat rhoncus in."
                + " Donec aliquet enim lacus, a dapibus tortor volutpat luctus. Nulla massa quam, accumsan quis ligula ut, auctor tincidunt justo.", "author.example@email.com");
        TemplateDTO temp2 = new TemplateDTO("TEMP2", "APAC STANDARD", "1.\tRegion:\r\n2.\tDescription of Activity:\r\n\r\n\r\n Fin", "author2.example@email.com");
        TemplateDTO temp3 = new TemplateDTO("TEMP3", "MYSTERY TEMPLATE", "FIELD CONTENT", "author3.example@email.com");
        TemplateDTO temp4 = new TemplateDTO("TEMP4", "EMEA ENHANCED", "FIELD CONTENT", "author.example@email.com");
        TemplateDTO temp5 = new TemplateDTO("TEMP5", "NAM ENHANCED", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin bibendum molestie augue, eu elementum ipsum commodo ut. Nullam tristique posuere pharetra. Integer blandit dolor non massa dignissim "
                + "tincidunt. Cras convallis ante ornare dolor vestibulum, vel viverra tortor vulputate. Nam vehicula ornare pellentesque. Vestibulum venenatis sagittis felis nec mollis. Integer dictum varius sem placerat"
                + " fermentum. Pellentesque imperdiet massa in lacinia vehicula. Donec at aliquam neque. Ut congue, mi vitae sagittis pulvinar, velit augue cursus urna, nec posuere purus ante id augue. Donec sapien lectus,"
                + " euismod sed massa at, imperdiet feugiat nunc. Proin dapibus dictum nisi sed finibus. Morbi pellentesque cursus ullamcorper. Praesent ullamcorper non massa id tincidunt. Etiam auctor, sapien nec tristique"
                + " porta, nisl nunc rhoncus nibh, maximus hendrerit quam dui sed libero. Aliquam egestas vulputate sapien tincidunt tristique. Aliquam nec nunc ut turpis efficitur gravida ut quis sem. Maecenas ac sapien "
                + "sed dolor porta maximus ut id leo. Suspendisse potenti. Sed a diam aliquet, interdum risus id, fermentum lectus. Nullam elit lorem, malesuada a elementum nec, laoreet eget nunc. Aliquam pharetra purus id "
                + "urna pretium, at congue sapien hendrerit. Morbi rhoncus consectetur aliquam. Vivamus vel mauris dictum, tincidunt urna cursus, euismod magna. Vestibulum pulvinar hendrerit augue, ut rutrum erat rhoncus in."
                + " Donec aliquet enim lacus, a dapibus tortor volutpat luctus. Nulla massa quam, accumsan quis ligula ut, auctor tincidunt justo."+
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin bibendum molestie augue, eu elementum ipsum commodo ut. Nullam tristique posuere pharetra. Integer blandit dolor non massa dignissim "
                + "tincidunt. Cras convallis ante ornare dolor vestibulum, vel viverra tortor vulputate. Nam vehicula ornare pellentesque. Vestibulum venenatis sagittis felis nec mollis. Integer dictum varius sem placerat"
                + " fermentum. Pellentesque imperdiet massa in lacinia vehicula. Donec at aliquam neque. Ut congue, mi vitae sagittis pulvinar, velit augue cursus urna, nec posuere purus ante id augue. Donec sapien lectus,"
                + " euismod sed massa at, imperdiet feugiat nunc. Proin dapibus dictum nisi sed finibus. Morbi pellentesque cursus ullamcorper. Praesent ullamcorper non massa id tincidunt. Etiam auctor, sapien nec tristique"
                + " porta, nisl nunc rhoncus nibh, maximus hendrerit quam dui sed libero. Aliquam egestas vulputate sapien tincidunt tristique. Aliquam nec nunc ut turpis efficitur gravida ut quis sem. Maecenas ac sapien "
                + "sed dolor porta maximus ut id leo. Suspendisse potenti. Sed a diam aliquet, interdum risus id, fermentum lectus. Nullam elit lorem, malesuada a elementum nec, laoreet eget nunc. Aliquam pharetra purus id "
                + "urna pretium, at congue sapien hendrerit. Morbi rhoncus consectetur aliquam. Vivamus vel mauris dictum, tincidunt urna cursus, euismod magna. Vestibulum pulvinar hendrerit augue, ut rutrum erat rhoncus in."
                + " Donec aliquet enim lacus, a dapibus tortor volutpat luctus. Nulla massa quam, accumsan quis ligula ut, auctor tincidunt justo.", "author2.example@email.com");
        TemplateDTO temp6 = new TemplateDTO("TEMP6", "Magic Templ8 Ball", "FIELD CONTENT", "author3.example@email.com");
        TemplateDTO temp7 = new TemplateDTO("TEMP7", "NAM STANDARD", "FIELD CONTENT", "author2.example@email.com");
        TemplateDTO temp8 = new TemplateDTO("TEMP8", "APAC ENHANCED", "FIELD CONTENT", "author2.example@email.com");

        templateListDummy.add(temp1);
        templateListDummy.add(temp2);
        templateListDummy.add(temp3);
        templateListDummy.add(temp4);
        templateListDummy.add(temp5);
        templateListDummy.add(temp6);
        templateListDummy.add(temp7);
        templateListDummy.add(temp8);
    }

    List<TemplateDTO> templateListDummy = new ArrayList<>(); // Dummy list for testing purposes
}