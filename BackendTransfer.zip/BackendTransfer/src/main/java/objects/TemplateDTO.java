package objects;

public class TemplateDTO {

    public TemplateDTO(){

    }

    public TemplateDTO(String templateId, String templateTitle, String templateBody, String templateAuthor) {
        this.templateId = templateId;
        this.templateTitle = templateTitle;
        this.templateBody = templateBody;
        this.templateAuthor = templateAuthor;

    }
        private String templateId;
        private String templateTitle;
        private String templateBody;
        private String templateAuthor;




    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) { this.templateId = templateId; }

    public String  getTemplateTitle() { return templateTitle; }

    public void setTemplateTitle(String templateTitle) {this.templateTitle = templateTitle;}

    public String getTemplateBody() {return templateBody;}

    public void setTemplateBody(String templateBody) { this.templateBody = templateBody;}

    public String getTemplateAuthor() {return templateAuthor; }

    public void setTemplateAuthor(String templateAuthor) { this.templateAuthor = templateAuthor; }

}

