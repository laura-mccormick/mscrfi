package objects;

import java.util.List;

public class TestDTO {

    private String[] stringArray;
    private List<String> stringList;
    private String stringFilthy;

    public String[] getStringArray() {
        return stringArray;
    }

    public void setStringArray(String[] stringArray) {
        this.stringArray = stringArray;
    }

    public List<String> getStringList() {
        return stringList;
    }

    public void setStringList(List<String> stringList) {
        this.stringList = stringList;
    }

    public String getStringFilthy() {
        return stringFilthy;
    }

    public void setStringFilthy(String stringFilthy) {
        this.stringFilthy = stringFilthy;
    }
}
