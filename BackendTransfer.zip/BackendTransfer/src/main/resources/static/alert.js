var alertTool = angular.module('alertTool', ['ngRoute']);

alertTool.config(function ($routeProvider){
    $routeProvider

    .when('/', {
        templateUrl: 'alertList.html',
        controller: 'alertRoute'
     })

    .when('/conversation/:alertId', {
             templateUrl: 'conversation.html',
             controller: 'conversationRoute'
     })

	.when('/messageList/:conversationId', {
		templateUrl: 'messageList.html',
		controller: 'messageListRoute'
	})

    .when('/message/:messageId', {
             templateUrl: 'viewMessage.html',
             controller: 'viewMessageRoute'
     })

    .when('/newMessage/:alertId', {
            templateUrl: 'newMessage.html',
            controller: 'newMessageRoute'
     })

    .when('/storedTemplates', {
        templateUrl: 'storedTemplates.html'
    })

     .when('/createTemplate', {
        templateUrl: 'createTemplate.html'
     })


     .when('/storedTemplates/template/:templateId', {
            templateUrl: 'template.html',
            controller: 'storedTemplateRoute'
    })


});

alertTool.factory('Scopes', function ($rootScope) {
    var mem = {};

    return {
        store: function (key, value) {
            mem[key] = value;
        },
        get: function (key) {
            return mem[key];
        }
    };
});

alertTool.controller('alertRoute', function($scope){
});

alertTool.controller('newMessageRoute', function($scope, $routeParams, Scopes){
   Scopes.store('newMessageRoute', $scope);
   $scope.alertId = $routeParams.alertId;
});

alertTool.controller('conversationRoute', function($scope, $routeParams, Scopes){
    Scopes.store('conversationRoute', $scope);
    $scope.alertId = $routeParams.alertId;
});

alertTool.controller('messageListRoute', function($scope, $routeParams, Scopes){
    Scopes.store('messageListRoute', $scope);
    $scope.conversationId = $routeParams.conversationId;
});

alertTool.controller('viewMessageRoute', function($scope, $routeParams, Scopes){
	Scopes.store('viewMessageRoute', $scope);
    $scope.messageId = $routeParams.messageId;
});


alertTool.controller('storedTemplateRoute', function($scope, $routeParams, Scopes){
    Scopes.store('storedTemplateRoute', $scope);
    $scope.templateId = $routeParams.templateId;
});

alertTool.controller('templateRoute', function($scope, $routeParams, Scopes){
    Scopes.store('templateRoute', $scope);
    $scope.templateId = $routeParams.templateId;
});

alertTool.controller('alertsCtrl', function($scope, $http, Scopes){
	Scopes.store('alertsCtrl', $scope);

    // Dummy data from URL
     $http.get("http://localhost:8080/alert/fullListAlertsDummy").then(function(response) {
            $scope.alerts = response.data;

        });

    //// Actual data from DB - wont work on citi
    // $http.get("/alert/fullListActual").then(function(response) {
    //        $scope.alerts = response.data;
    //    });

    $scope.selId = -1;
    $scope.selAlert = function (alert, id){
       $scope.selectedAlert=alert;
       $scope.selId=id;

       var alertHref='#/conversation/'+$scope.selectedAlert.id;
       document.getElementById("viewRfiHref").href=alertHref;
       document.getElementById("viewRfiHref").classList.remove('greyOut');
       document.getElementById("viewRfiHref").classList.add('enable');

       var rfiHref='#/newMessage/'+$scope.selectedAlert.id;
       document.getElementById("newRfiHref").href=rfiHref;
       document.getElementById("newRfiHref").classList.remove('greyOut');
       document.getElementById("newRfiHref").classList.add('enable');
        }

    $scope.isSelAlert=function(alert){
        return $scope.selAlert===alert;
    }

	document.getElementById("searcher").addEventListener("keyup", searchAlerts);

	function searchAlerts() {
		var input = document.getElementById("searcher");
		var filter = input.value.toUpperCase();
		var table = document.getElementById("alertTable");
		var tr = table.getElementsByTagName("tr");
			
		for (i=0; 0<tr.length; i++){
			td = tr[i].getElementsByTagName("td")[1];
			if (td){
				if (td.innerHTML.toUpperCase().indexOf(filter) > -1){
					tr[i].style.display="";
				} else {
					tr[i].style.display="none";
				}
			}
		}
	}
	
	$scope.orderByMe=function(x){
       	$scope.myOrderBy=x;
    }
});

alertTool.controller('conversationCtrl', function($scope, $http, Scopes){
	Scopes.store('conversationCtrl', $scope);
	
 	$http.get("http://localhost:8080/conversation/conversationListFullDummy").then(function(response) {
        $scope.conversations = response.data;
 	}).finally(function(messages){
    $scope.filtConversations = $scope.conversations.filter(function (conversation){
            return conversation.alertId===Scopes.get('conversationRoute').alertId;
    	});
	});

	//// Actual data from DB
	//   $http.get("/rfi/fullListActual").then(function(response) {
	//           $scope.messages = response.data;
	//       });


    $scope.selId = -1;
    $scope.selConversation = function (conversation, id){
       $scope.selectedConversation=conversation;
       $scope.selId=id;
       var messageHref='#/messageList/'+$scope.selectedConversation.conversationId;
       document.getElementById("viewMessageListHref").href=messageHref;
       document.getElementById("viewMessageListHref").classList.remove('greyOut');
       document.getElementById("viewMessageListHref").classList.add('enable');
    }
			
    $scope.isSelConversation=function(conversation){
        return $scope.selectedConversation===conversation;
    }

	$scope.orderByMe=function(x){
       	$scope.myOrderBy=x;
    }
    
	$scope.updateConversation=function(conversation, id){

        document.getElementById("updateConvo").classList.remove('greyOut');
        document.getElementById("updateConvo").classList.add('enable');
        $http.post("http://localhost:8080/conversation/changeConversation/" + $scope.selectedConversation.conversationId).then(function(response){
        $scope.conversations.reload()},

        function(response){
        alert("Something didn't work!")});

	}
	
	document.getElementById("searcher").addEventListener("keyup", searchConversations);
	
	function searchConversations() {
		var input = document.getElementById("searcher");
		var filter = input.value.toUpperCase();
		var table = document.getElementById("conversationTable");
		var tr = table.getElementsByTagName("tr");
			
		for (i=0; 0<tr.length; i++){
			if(document.getElementsByName("searchField")[0].checked){
				td = tr[i].getElementsByTagName("td")[0];
			} else {
				td = tr[i].getElementsByTagName("td")[1];
			}
			if (td){
				if (td.innerHTML.toUpperCase().indexOf(filter) > -1){
					tr[i].style.display="";
				} else {
					tr[i].style.display="none";
				}
			}
		}
	}
});

alertTool.controller('newMessageCtrl', function($scope, $http, Scopes){

    // Fetch the templates
     $http.get("http://localhost:8080/storedTemplates/templateListFullDummy").then(function(response) {
            $scope.templates = response.data;
         });

	var pdfGenerated = false;
	var alertId = Scopes.get('newMessageRoute').alertId;
	var pdf = new jsPDF();
	
	// this way of getting the alert description is janky, better to retrieve from database: used for dev/test purposes only
	var messageAlert = Scopes.get('alertsCtrl').selectedAlert;
	
	//$http.get("http://localhost:8080/alert/getAlertById/"+alertId).then(function(response) {
	//	var messageAlert = response.data;
	//});
	
	var attachments = document.getElementById("attachments");
	if ('files' in attachments){
		if (attachments.files.length > 0) {
			console.log('Files uploaded');
			document.getElementById('processedAttachments').files = attachments;
		}
	}
	
	var alertDesc = messageAlert.desc;
	document.getElementById('generatePDF').onclick = function() {
		console.log('Generating PDF');
		pdf.text(alertDesc, 10, 10);
		var pdfName = "alert"+alertId+".pdf";
		pdfGenerated=true;
		pdf.save(pdfName);
	}
	
	var pdfGenerated = false;
	var alertId = Scopes.get('newMessageRoute').alertId;
	
	// this way of getting the alert description is bad and nasty
	var messageAlert = Scopes.get('alertsCtrl').selectedAlert;
	
	//$http.get("http://localhost:8080/alert/getAlertById/"+alertId).then(function(response) {
	//	var messageAlert = response.data;
	//});
	
	var attachments = document.getElementById("attachments");
	if ('files' in attachments){
		if (attachments.files.length > 0) {
			document.getElementById('processedAttachments').files = attachments;
		}
	}
	
	var alertDesc = messageAlert.desc;
//	document.getElementById('attachPDF').onclick = function() {
//		if(this.checked){
//			if(!pdfGenerated){
//				console.log('Generating PDF');
//				var pdf = new jsPDF();
//
//				pdf.text(alertDesc, 10, 10);
//				var pdfName = "alert"+alertId+".pdf";
//				pdf.save(pdfName);
//				pdfGenerated=true;
//				document.getElementById('generatedPDF').files = pdf;
//			} else {
//				console.log('PDF exists - attaching');
//			}
//		} else {
//			console.log('PDF not being attached');
//		}
//	}
	var pdfGenerated = false;
	var alertId = Scopes.get('newMessageRoute').alertId;
	
	// this way of getting the alert description is bad and nasty
	var messageAlert = Scopes.get('alertsCtrl').selectedAlert;
	
	//$http.get("http://localhost:8080/alert/getAlertById/"+alertId).then(function(response) {
	//	var messageAlert = response.data;
	//});
	
	var attachments = document.getElementById("attachments");
	if ('files' in attachments){
		if (attachments.files.length > 0) {
			document.getElementById('processedAttachments').value = attachments;
		}
	}
	
	var alertDesc = messageAlert.desc;
//	document.getElementById('attachPDF').onclick = function() {
//		if(this.checked){
//			if(!pdfGenerated){
//				console.log('Generating PDF');
//				var pdf = new jsPDF();
//
//				pdf.text(alertDesc, 10, 10);
//				var pdfName = "alert"+alertId+".pdf";
//				pdf.save(pdfName);
//				pdfGenerated=true;
//				document.getElementById('generatedPDF').value = pdf;
//			} else {
//				console.log('PDF exists - attaching');
//			}
//		} else {
//			console.log('PDF not being attached');
//		}
//	}
	
	$scope.orderByMe=function(x){
       	$scope.myOrderBy=x;
    }

    $scope.selTemplate = function(template){
        $scope.selectedTemplate=template;
        document.getElementById("useTemplate").classList.remove('greyOut');
        document.getElementById("useTemplate").classList.add('enable');
    }

    $scope.useTemplate = function() {
        var newBody = $scope.selectedTemplate.templateBody + "\n" + $scope.messageBody;
        $scope.messageBody = newBody;
    }
});

alertTool.controller('viewMessageCtrl', function($scope, $http, Scopes){
 	$http.get("http://localhost:8080/message/messageByMessageId/"+Scopes.get('viewMessageRoute').messageId).then(function(response) {
    	$scope.selectedMessage = response.data;
    });
 	
	$http.get("http://localhost:8080/attachment/attachmentListFullDummy").then(function(response) {
	    $scope.files = response.data;
    });
});


alertTool.controller('messageListCtrl', function($scope, $http, Scopes){
  	Scopes.store('messageListCtrl', $scope);
  	
  	$http.get("http://localhost:8080/message/messagesListByRfiIdDB/"+Scopes.get('messageListRoute').conversationId).then(function(response) {
        $scope.messages = response.data;
 	});
	
    $scope.selId = -1;
    $scope.selMessage = function (message, id){
       $scope.selectedMessage=message;
       $scope.selId=id;
       var messageHref='#/message/'+$scope.selectedMessage.messageId;
       document.getElementById("viewMessageHref").href=messageHref;
       document.getElementById("viewMessageHref").classList.remove('greyOut');
       document.getElementById("viewMessageHref").classList.add('enable');
    }
			
    $scope.isSelMessage=function(message){
        return $scope.selMessage===message;
    }

    $scope.orderByMe=function(x){       
        $scope.myOrderBy=x;
    }
});



alertTool.controller('storedTemplatesCtrl', function($scope, $http, Scopes){
     Scopes.store('storedTemplatesCtrl', $scope);

     $http.get("http://localhost:8080/storedTemplates/templateListFullDummy").then(function(response) {
        $scope.templates = response.data;
     });

    $scope.selId = -1;
    $scope.selTemplate = function(template, id){
        $scope.selectedTemplate=template;
        $scope.selId=id;
        var templateHref='#/storedTemplates/template/'+$scope.selectedTemplate.templateId;
        document.getElementById("viewTemplateHref").href=templateHref;
        document.getElementById("viewTemplateHref").classList.remove('greyOut');
        document.getElementById("viewTemplateHref").classList.add('enable');
    }

    $scope.isSelTemplate=function(template){
        return $scope.selTemplate===template;
    }



     });

alertTool.controller('createTemplateCtrl', function($scope, $window, $http, Scopes) {
    Scopes.store('createTemplateCtrl', $scope);
    $scope.saveTemplate = function() {
        if($scope.templateInputTitle){
            $http({
                method: 'POST',
                url: 'http://localhost:8080/createTemplate/save',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                transformRequest: function(obj) {
                    var str = [];
                    for(var p in obj)
                    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data: {title : $scope.templateInputTitle, body : $scope.templateInputBody}
            }).success(function() {
                           window.alert("Saved!")
                        })
                        .error(function() {
                            window.alert("Failed to save!")
                        });
        } else{
            window.alert("Template requires a title to be saved.")
        }
    };

 });

 alertTool.controller('templateViewCtrl', function($scope, $http, Scopes) {
 Scopes.store('templateViewCtrl', $scope);

 $http.get("http://localhost:8080/storedTemplates/template/"+Scopes.get('storedTemplateRoute').templateId).then(function(response) {
        $scope.template = response.data;
     });
 });

